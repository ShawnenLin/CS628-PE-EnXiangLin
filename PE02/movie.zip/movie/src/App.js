import React, { useState } from 'react';

const movies = [
  { title: "The Shawshank Redemption", genre: "Drama", releaseYear: 1994 },
  { title: "The Godfather", genre: "Crime", releaseYear: 1972 },
  { title: "The Dark Knight", genre: "Action", releaseYear: 2008 },
  { title: "12 Angry Men", genre: "Drama", releaseYear: 1957 },
  { title: "Pulp Fiction", genre: "Crime", releaseYear: 1994 },
  { title: "Inception", genre: "Sci-Fi", releaseYear: 2010 },
  { title: "The Lord of the Rings: The Fellowship of the Ring", genre: "Fantasy", releaseYear: 2001 },
];

const MovieList = () => {
  const [selectedGenre, setSelectedGenre] = useState('All Genres');

  const handleGenreChange = (event) => {
    setSelectedGenre(event.target.value);
  };

  const filteredMovies = selectedGenre === 'All Genres' ? 
    movies : 
    movies.filter(movie => movie.genre === selectedGenre);

  const handleMovieClick = (movieTitle) => {
    alert(`You clicked on "${movieTitle}"`);
  };

  return (
    <div>
      <h1>Movie List</h1>
      <select value={selectedGenre} onChange={handleGenreChange}>
        <option value="All Genres">All Genres</option>
        <option value="Drama">Drama</option>
        <option value="Crime">Crime</option>
        <option value="Action">Action</option>
        <option value="Sci-Fi">Sci-Fi</option>
        <option value="Fantasy">Fantasy</option>
      </select>
      <ul>
        {filteredMovies.map(movie => (
          <li key={movie.title} onClick={() => handleMovieClick(movie.title)}> 
            <h3>{movie.title}</h3>
            <p>Genre: {movie.genre}</p>
            <p>Release Year: {movie.releaseYear}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MovieList;